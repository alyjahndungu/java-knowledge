package readinglist

class Book {

    static constraints = {
    }

    String reader
  	String isbn
  	String title
  	String author
  	String description
 
}
