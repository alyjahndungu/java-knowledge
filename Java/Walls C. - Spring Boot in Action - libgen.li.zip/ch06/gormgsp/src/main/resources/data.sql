insert into Reader (username, password, fullname, version) values ('craig', 'password', 'Craig Walls', 1);
insert into Reader (username, password, fullname, version) values ('walt', 'marceline', 'Walt Disney', 1);
