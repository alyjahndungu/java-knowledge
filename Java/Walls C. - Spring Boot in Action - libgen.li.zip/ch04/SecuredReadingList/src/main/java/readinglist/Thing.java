package readinglist;

public class Thing {

}
