@Grab("h2")
@Grab("spring-boot-starter-thymeleaf")
class Grabs {}